﻿using System;
using System.Collections.Generic;

// Token: 0x0200000C RID: 12
public static class ToggleStateManager
{
	// Token: 0x04000026 RID: 38
	public static Dictionary<string, bool> ToggleStates = new Dictionary<string, bool>();
}
