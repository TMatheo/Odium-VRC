﻿using System;

namespace Odium.Components
{
	// Token: 0x02000058 RID: 88
	public class CoroutineManager
	{
		// Token: 0x0600025B RID: 603 RVA: 0x00015205 File Offset: 0x00013405
		public static void Init()
		{
		}
	}
}
