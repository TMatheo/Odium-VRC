﻿using System;

namespace Odium.Components
{
	// Token: 0x02000061 RID: 97
	public enum Rank
	{
		// Token: 0x04000134 RID: 308
		Visitor,
		// Token: 0x04000135 RID: 309
		NewUser,
		// Token: 0x04000136 RID: 310
		User,
		// Token: 0x04000137 RID: 311
		Known,
		// Token: 0x04000138 RID: 312
		Trusted
	}
}
