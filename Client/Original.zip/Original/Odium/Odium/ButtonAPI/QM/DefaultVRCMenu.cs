﻿using System;

namespace Odium.ButtonAPI.QM
{
	// Token: 0x0200007B RID: 123
	public enum DefaultVRCMenu
	{
		// Token: 0x040001AE RID: 430
		SelectedUser_Local,
		// Token: 0x040001AF RID: 431
		Dashboard,
		// Token: 0x040001B0 RID: 432
		Notifications,
		// Token: 0x040001B1 RID: 433
		Camera,
		// Token: 0x040001B2 RID: 434
		Here,
		// Token: 0x040001B3 RID: 435
		GeneralSettings,
		// Token: 0x040001B4 RID: 436
		AudioSettings
	}
}
