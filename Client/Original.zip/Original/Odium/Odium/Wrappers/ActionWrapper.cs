﻿using System;
using VRC;

namespace Odium.Wrappers
{
	// Token: 0x02000040 RID: 64
	internal class ActionWrapper
	{
		// Token: 0x040000BD RID: 189
		public static Player portalSpamPlayer;

		// Token: 0x040000BE RID: 190
		public static bool portalSpam;

		// Token: 0x040000BF RID: 191
		public static Player portalTrapPlayer;

		// Token: 0x040000C0 RID: 192
		public static bool portalTrap;

		// Token: 0x040000C1 RID: 193
		public static bool massPortalSpam;

		// Token: 0x040000C2 RID: 194
		public static bool serialize;

		// Token: 0x040000C3 RID: 195
		public static Player attachTarget;
	}
}
