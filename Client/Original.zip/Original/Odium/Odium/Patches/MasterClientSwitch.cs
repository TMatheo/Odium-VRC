﻿using System;

namespace Odium.Patches
{
	// Token: 0x0200002D RID: 45
	internal class MasterClientSwitch
	{
	}
}
