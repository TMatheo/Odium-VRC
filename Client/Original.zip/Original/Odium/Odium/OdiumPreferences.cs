﻿using System;

namespace Odium
{
	// Token: 0x0200001B RID: 27
	public class OdiumPreferences
	{
		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000BA RID: 186 RVA: 0x000060B8 File Offset: 0x000042B8
		// (set) Token: 0x060000BB RID: 187 RVA: 0x000060C0 File Offset: 0x000042C0
		public bool AllocConsole { get; set; } = true;
	}
}
