﻿using System;

namespace Odium
{
	// Token: 0x0200001C RID: 28
	public enum LogLevel
	{
		// Token: 0x0400004B RID: 75
		Info,
		// Token: 0x0400004C RID: 76
		Debug,
		// Token: 0x0400004D RID: 77
		Warning,
		// Token: 0x0400004E RID: 78
		Error
	}
}
