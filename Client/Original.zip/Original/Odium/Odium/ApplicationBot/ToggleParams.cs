﻿using System;

namespace Odium.ApplicationBot
{
	// Token: 0x02000092 RID: 146
	public class ToggleParams
	{
		// Token: 0x17000064 RID: 100
		// (get) Token: 0x06000429 RID: 1065 RVA: 0x00021365 File Offset: 0x0001F565
		// (set) Token: 0x0600042A RID: 1066 RVA: 0x0002136D File Offset: 0x0001F56D
		public bool Enabled { get; set; }
	}
}
