﻿using System;

namespace Odium.ApplicationBot
{
	// Token: 0x02000090 RID: 144
	public class TeleportParams
	{
		// Token: 0x17000060 RID: 96
		// (get) Token: 0x0600041F RID: 1055 RVA: 0x0002130F File Offset: 0x0001F50F
		// (set) Token: 0x06000420 RID: 1056 RVA: 0x00021317 File Offset: 0x0001F517
		public string UserId { get; set; }
	}
}
