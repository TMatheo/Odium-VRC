﻿using System;

namespace Odium.ApplicationBot
{
	// Token: 0x02000091 RID: 145
	public class PositionParams
	{
		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000422 RID: 1058 RVA: 0x00021329 File Offset: 0x0001F529
		// (set) Token: 0x06000423 RID: 1059 RVA: 0x00021331 File Offset: 0x0001F531
		public float X { get; set; }

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000424 RID: 1060 RVA: 0x0002133A File Offset: 0x0001F53A
		// (set) Token: 0x06000425 RID: 1061 RVA: 0x00021342 File Offset: 0x0001F542
		public float Y { get; set; }

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000426 RID: 1062 RVA: 0x0002134B File Offset: 0x0001F54B
		// (set) Token: 0x06000427 RID: 1063 RVA: 0x00021353 File Offset: 0x0001F553
		public float Z { get; set; }
	}
}
