﻿using System;

namespace Odium.ApplicationBot
{
	// Token: 0x02000093 RID: 147
	public class SpeedParams
	{
		// Token: 0x17000065 RID: 101
		// (get) Token: 0x0600042C RID: 1068 RVA: 0x0002137F File Offset: 0x0001F57F
		// (set) Token: 0x0600042D RID: 1069 RVA: 0x00021387 File Offset: 0x0001F587
		public int Speed { get; set; }
	}
}
