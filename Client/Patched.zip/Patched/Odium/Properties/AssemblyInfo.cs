﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using MelonLoader;
using Odium;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: MelonInfo(typeof(OdiumEntry), "Odium", "0.0.5", "Zuno", null)]
[assembly: MelonGame("VRChat", "VRChat")]
[assembly: AssemblyCompany("Odium")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+d4e099fa3d42b9035096f7666ccdd9fb67a2d6c8")]
[assembly: AssemblyProduct("Odium")]
[assembly: AssemblyTitle("Odium")]
