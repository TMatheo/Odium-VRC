﻿using System;

namespace Odium.Odium
{
	// Token: 0x02000038 RID: 56
	[Serializable]
	public class UserInfo
	{
		// Token: 0x040000AD RID: 173
		public string id;

		// Token: 0x040000AE RID: 174
		public string username;

		// Token: 0x040000AF RID: 175
		public bool isBanned;

		// Token: 0x040000B0 RID: 176
		public string bannedAt;
	}
}
