﻿using System;

namespace Odium.ApplicationBot
{
	// Token: 0x0200008F RID: 143
	public class JoinWorldParams
	{
		// Token: 0x1700005F RID: 95
		// (get) Token: 0x0600041C RID: 1052 RVA: 0x000212F5 File Offset: 0x0001F4F5
		// (set) Token: 0x0600041D RID: 1053 RVA: 0x000212FD File Offset: 0x0001F4FD
		public string WorldId { get; set; }
	}
}
