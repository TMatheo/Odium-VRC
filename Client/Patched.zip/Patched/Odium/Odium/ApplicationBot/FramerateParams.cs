﻿using System;

namespace Odium.ApplicationBot
{
	// Token: 0x02000094 RID: 148
	public class FramerateParams
	{
		// Token: 0x17000066 RID: 102
		// (get) Token: 0x0600042F RID: 1071 RVA: 0x00021399 File Offset: 0x0001F599
		// (set) Token: 0x06000430 RID: 1072 RVA: 0x000213A1 File Offset: 0x0001F5A1
		public int Framerate { get; set; }
	}
}
