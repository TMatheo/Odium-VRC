﻿using System;
using UnityEngine;

namespace Odium.Wrappers
{
	// Token: 0x02000046 RID: 70
	internal class Portal
	{
		// Token: 0x060001C9 RID: 457 RVA: 0x0000F385 File Offset: 0x0000D585
		public static void SpawnPortal(Vector3 positon, string worldSecureCode)
		{
			ObjectPublicAbstractSealedSiInSiUIBoSiGaTrDi2Unique.Method_Public_Static_Boolean_String_Boolean_Vector3_Quaternion_String_Action_1_LocalizableString_0(worldSecureCode, true, positon, new Quaternion(0f, 0f, 0f, 0f), null, null);
		}

		// Token: 0x060001CA RID: 458 RVA: 0x0000F3AC File Offset: 0x0000D5AC
		public static void SpawnSticker(Vector3 positon, string stickerNameOrID)
		{
		}
	}
}
